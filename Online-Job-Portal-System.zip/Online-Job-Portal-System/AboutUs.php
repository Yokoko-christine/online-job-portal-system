<?xml version="1.0"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="cs" lang="cs">
<head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <meta http-equiv="content-language" content="cs" />
    <meta name="robots" content="all,follow" />

    <meta name="author" content="All: ... [Nazev webu - www.url.cz]; e-mail: info@url.cz" />
    <meta name="copyright" content="Design/Code: Vit Dlouhy [Nuvio - www.nuvio.cz]; e-mail: vit.dlouhy@nuvio.cz" />
    
    <title>JOB PORTAL</title>
    <meta name="description" content="..." />
    <meta name="keywords" content="..." />
    
    <link rel="index" href="./" title="Home" />
    <link rel="stylesheet" media="screen,projection" type="text/css" href="./css/main.css" />
    <link rel="stylesheet" media="print" type="text/css" href="./css/print.css" />
    <link rel="stylesheet" media="aural" type="text/css" href="./css/aural.css" />
    <style type="text/css">
<!--
.style1 {
	color: #000066;
	font-weight: bold;
}

.body{margin: 0;
    padding: 0;
    width: 100%;
    height: 100%;
    overflow: hidden;
}
h2 {
    font-size: 28px;
    padding-top: 50px;
    /* Increase font size for h2 */
}

p {
    font-size: 18px; /* Increase font size for p */
    line-height: 1.5; /* Adjust line height for better readability */
}

-->
    </style>
</head>

<body id="www-url-cz">
<!-- Main -->
<div id="main" class="box" style="width: 100%; height: 100%; margin: 0; padding: 0;">

<?php 
include "Header.php"
?>
<?php 
include "menu.php"
?>   


         
           
            <!-- /article -->

            <hr class="noscreen" />

           
            <!-- /article -->

            <hr class="noscreen" />
            
            <!-- Article -->
           
            <!-- /article -->

            <hr class="noscreen" />

            <!-- Article -->
            <div class="article">
                <h2><span><b><a href="#">About Us</a></b></span></h2>
               

                <p>Welcome to the Online Job Portal. It provides the facility for Job Seekers to search for jobs that match their qualifications. Job Seekers can register on the web portal, creating profiles that include educational information. You can explore various job listings and easily apply for positions.</p>


                <p>This Portal is also designed for the various employer who required to recruit employees in their organization. Employer can registered himself on the web portal and then he can upload information of various job vacancies in their organization. Employeer can view the applications of Job Seeker and send call latter to the job seekers.</p><b><b>
				
              <p class="btn-more box noprint">&nbsp;</p>
          </div> <!-- /article -->

            <hr class="noscreen" />
            
        </div> <!-- /content -->



    </div> <!-- /page-in -->
    </div> <!-- /page -->

 

</div> <!-- /main -->

</body>
</html>
