<?php
session_start();
if(isset($_SESSION['$UserName'])){
	header('location:Admin/index.php');
} 
if(isset($_SESSION['$UserName_job'])){
	header('location:JobSeeker/index.php');
} 
if(isset($_SESSION['$UserName_emp'])){
	header('location:Employer/index.php');
} 
?>
<?xml version="1.0"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="cs" lang="cs" style="width: 100%; height: 100%; margin: 0; padding: 0;">
<head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <meta http-equiv="content-language" content="cs" />
    <meta name="robots" content="all,follow" />

    <meta name="author" content="All: ... [Nazev webu - www.url.cz]; e-mail: info@url.cz" />
    <meta name="copyright" content="Design/Code: Vit Dlouhy [Nuvio - www.nuvio.cz]; e-mail: vit.dlouhy@nuvio.cz" />
    
    <title>JOB PORTAL</title>
    <meta name="description" content="..." />
    <meta name="keywords" content="..." />
    
    <link rel="index" href="./" title="Home" />
    <link rel="stylesheet" media="screen,projection" type="text/css" href="./css/main.css" />
    <link rel="stylesheet" media="print" type="text/css" href="./css/print.css" />
    <link rel="stylesheet" media="aural" type="text/css" href="./css/aural.css" />
    <style type="text/css">
<!--
.style1 {
	color: #000066;
	font-weight: bold;
}
.style2 {
	font-size: medium;
	font-weight: bold;
}
body {
    background-image: url("C:\xampp\htdocs\Online-Job-Portal-System\design\jobb.jpg");
    background-size: cover;
    background-repeat: no-repeat;
    background-attachment: fixed;
    margin: 0;
    padding: 0;
    width: 100%;
    height: 100%;
}

h2 {
    margin: 60px; /* Remove any default margin */
    display: flex;
    justify-content: center; /* Center horizontally */
    align-items: center; /* Center vertically */
    color: white;
}

.image-container {
    width: 2700px; /* Total width of all three images */
    white-space: nowrap; /* Prevents images from wrapping */
    overflow: hidden; /* Hides the overflow */
    animation: scrollImages 10s linear infinite; /* Animation properties */
}

/* Keyframes for the animation */
@keyframes scrollImages {
    0% {
        transform: translateX(0); /* Initial position */
    }
    100% {
        transform: translateX(-900px); /* Move left by the width of one image */
    }
}

/* Individual image styles */
.image-container img {
    display: inline-block; /* Display images in a row */
    margin-right: 10px; /* Margin between images */
}




-->
    </style>
</head>

<body id="www-url-cz" style="width: 100%; height: 100%; margin: 0; padding: 0;">
<!-- Main -->
<div id="main" class="box" style="width: 100%; height: 100%; margin: 0; padding: 0;">

<?php 
include "Header.php"
?>
<?php 
include "menu.php"
?>   

            <!-- Article -->
            <div class="article">
            <h2><span><a href="#">WELCOME TO JOB SEARCHING AND APPLICATION PORTAL</a></span></h2>

            

    <div class="image-container">
        <img src="design/job.jpg" alt="" width="900" height="300" />
        <img src="design/jobb.jpg" alt="" width="900" height="300" />
        <img src="design/job2.jpg" alt="" width="900" height="300" />
    </div>

          


                <div style="display: flex; justify-content: space-between;">
                <div style="width: 48%;">
                <p style="font-size: 16px; font-weight: bold;"> <span class="style2">W</span>elcome to the Online Job Portal. It provides the facility for Job Seekers to search for jobs that match their qualifications. Job Seekers can register on the web portal, creating profiles that include educational information. You can explore various job listings and easily apply for positions.</p>
            </div>
                <div style="width: 48%;">
            <p style="font-size: 16px; font-weight: bold;">This portal is also designed to cater to employers in need of recruiting employees for their organizations. Employers can register on the web portal and upload information about job vacancies in their organization. Employers can review applications from Job Seekers and communicate with potential candidates by sending call letters.</p>
    </div>
</div>

              <p class="btn-more box noprint">&nbsp;</p>
          </div> <!-- /article -->

            <hr class="noscreen" />
            
        </div> <!-- /content -->



    </div> <!-- /page-in -->
    </div> <!-- /page -->

 

</div> <!-- /main -->

</body>
</html>
