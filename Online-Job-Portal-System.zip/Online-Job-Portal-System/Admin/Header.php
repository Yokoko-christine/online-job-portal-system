    <!-- Header -->
    <div id="header">

        <!-- Logotyp -->
      
        <hr class="noscreen" />          

        <!-- Quick links -->
        <div class="noscreen noprint">
            <p><em>Quick links: <a href="#content">content</a>, <a href="#tabs">navigation</a>, <a href="#search">search</a>.</em></p>
            <hr />
        </div>
        <div style="position: fixed; top: 0; left: 0; width: 100%; height: 98px; border: 1px solid black; background-color: blue; color: white; font-size: 30px; text-align: center; font-weight: bold;padding-top: 50px;">JOB SEARCHING AND APPLICATION PORTAL<br> <br>JOB SEEKERS PAGE

    </div>

        <!-- Search -->
       

    </div> <!-- /header -->